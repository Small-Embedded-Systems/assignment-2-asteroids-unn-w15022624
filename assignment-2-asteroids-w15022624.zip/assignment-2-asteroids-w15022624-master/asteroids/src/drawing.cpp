#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>
#include <utilities.h>
#include <controls.h>
#include <drawing.h>
#include <physics.h>

//initialise display
Display * lcd = Display::theDisplay();

typedef uint16_t colour_t;
#define rgb(r,g,b) ((uint16_t)(31 * r /255)<<11 | (uint16_t)(63 * g /255)<<5 | (uint16_t)(31 * b /255))
const colour_t background = rgb(0, 0, 0);

void screen(void){
	lcd->setTextSize(1);
}

//double buffering
void startDoubleBuffering(void){
    uint16_t * buffer = lcd-> getFb();
    uint16_t * frame2 = buffer + (480 * 272);
    LPC_LCD-> UPBASE = (uint32_t)frame2;
}

//second buffer
void switchBuffers(void){
    unsigned int b;
    b = LPC_LCD->UPBASE;
    LPC_LCD->UPBASE = (uint32_t)lcd->getFb();
    lcd->setFb((uint16_t *)b);
}

//create the game display
void draw(void){
        lcd->fillScreen(background);
        createLasers(active);
        createAsteroids(astactive);
        lcd->drawRect(0, 0, 480, 15, WHITE);
        lcd->setCursor(40, 5);
        lcd->printf("Lives Left : %i", lives);
        lcd->setCursor(190, 5);
        lcd->printf("Current Time : %i", activeTime);
				lcd->setCursor(340, 5);
        lcd->printf("Total Score : %i", activeTimeTotal);
				if(shieldHealth == 3){
					//full shields
					lcd->drawLine( originX + leftX, originY + leftY, originX + pointX, originY + pointY, WHITE);
					lcd->drawLine( originX + leftX, originY + leftY, originX + rightX, originY + rightY, WHITE);
					lcd->drawLine( originX + rightX, originY + rightY, originX + pointX, originY + pointY, WHITE);
				}
				if(shieldHealth == 2){
					//mid-strength shields
					lcd->drawLine( originX + leftX, originY + leftY, originX + pointX, originY + pointY, WHITE);
					lcd->drawLine( originX + leftX, originY + leftY, originX + rightX, originY + rightY, WHITE);
					lcd->drawLine( originX + rightX, originY + rightY, originX + pointX, originY + pointY, RED);
				}
				if(shieldHealth == 1){
					//low shields
					lcd->drawLine( originX + leftX, originY + leftY, originX + pointX, originY + pointY, RED);
					lcd->drawLine( originX + leftX, originY + leftY, originX + rightX, originY + rightY, WHITE);
					lcd->drawLine( originX + rightX, originY + rightY, originX + pointX, originY + pointY, RED);
				}
				if(shieldHealth < 1){
					//no shields
					lcd->drawLine( originX + leftX, originY + leftY, originX + pointX, originY + pointY, RED);
					lcd->drawLine( originX + leftX, originY + leftY, originX + rightX, originY + rightY, RED);
					lcd->drawLine( originX + rightX, originY + rightY, originX + pointX, originY + pointY, RED);
				}
				shield();
        switchBuffers();
}

//game over screen
void gameEnd(void){
	lcd->setTextSize(2);
	lcd->fillScreen(background);
	lcd->setCursor(180, 80);
	lcd->printf("GAME OVER");
	lcd->setCursor(155, 130);
	lcd->printf("YOU SCORED: %i", activeTimeTotal);
	lcd->setCursor(95, 180);
	lcd->printf("CLICK JOYSTICK IN TO RETRY");
	switchBuffers();
}

//create laser shape
void createLasers(struct laser * lst){
    while(lst) {
        lcd->fillCircle(lst-> x, lst-> y, 1, WHITE);
        lst = lst-> next;
    }
}

//create asteroid shape
void createAsteroids(struct asteroid *lst){
    while(lst) {
        lcd->fillCircle(lst->asteroidX,lst->asteroidY, 10, CYAN);
        lst = lst->next;
    }
}

//display shields
void shield(void){
	if(shieldHealth > 0){
		lcd->setCursor(350, 245);
		lcd->printf("Shield Integrity:");
	}
	if(shieldHealth == 1){
		lcd->fillRect(352, 255, 30, 5, WHITE);
	} else if(shieldHealth == 2){
		lcd->fillRect(352, 255, 30, 5, WHITE);
		lcd->fillRect(384, 255, 30, 5, WHITE);
	} else if(shieldHealth == 3){
		lcd->fillRect(352, 255, 30, 5, WHITE);
		lcd->fillRect(384, 255, 30, 5, WHITE);
		lcd->fillRect(416, 255, 30, 5, WHITE);
	}
}
