#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <display.h>
#include <mbed.h>
#include <physics.h>
#include <controls.h>

//joystick input
enum position { JLEFT,JDOWN,JRIGHT,JUP,JCENTRE};
DigitalIn buttons[] = {P5_0, P5_1, P5_4, P5_2, P5_3};

#define turningPoint 9
#define maxAcc 5
#define accInc 0.2

void controller(void){
  if(buttonPressed(JLEFT)){
    headingAngle = headingAngle + turningPoint;
  } else if(buttonPressed(JRIGHT)){
    headingAngle = headingAngle - turningPoint;
  } else if(buttonPressed(JUP)){
		if(accel < maxAcc){
			accel = accel + accInc;
		}
  }
	if(buttonPressed(JCENTRE)){
		laserSystem();
  }
}

//joystick controls post-game
bool retryGame(void){
	if(lives == 0 && buttonPressed(JCENTRE)){
		return true;
	}
	return false;
}

bool buttonPressed(enum position p){
    return !buttons[p];
}
