#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>
#include <utilities.h>
#include <controls.h>
#include <physics.h>
#include <drawing.h>

Ticker asteroids;
Ticker control;
Ticker drawing;
Ticker model;
static const float asteroidTick = 0.1;
static const float controlTick = 0.1;
static const float Dt = 0.01;
static const float drawTick = 0.025;

#define initLives 5

//assembley "C" call
extern "C" int fact(int); 


int main(){
    loadHeap();
    loadAsteroidHeap();
    startDoubleBuffering();
		initValues();
		lives = initLives;
	  asteroids.attach(asteroidSystem, asteroidTick);
	  control.attach(controller, controlTick);
		drawing.attach(draw, drawTick);
		model.attach(physics, Dt);	
		while(1){
		if(lives == 0){
			asteroids.detach();
			control.detach();
			drawing.detach();
			model.detach();
			gameEnd();
			if(retryGame()){
				screen();
				endScore = 0;
				activeTimeTotal = 0;
				initValues();
				lives = initLives;
				asteroids.attach(asteroidSystem, 0.1);
				control.attach(controller, 0.1);
				drawing.attach(draw, 0.025);
				model.attach(physics, Dt);
			}
		}
	}
}
